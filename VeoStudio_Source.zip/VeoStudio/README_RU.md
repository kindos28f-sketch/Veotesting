# Veo Studio — стартовый проект Android + Google Veo 3.1

## Что входит
- Android-приложение на Kotlin: prompt, формат 9:16/16:9, разрешение, статус задания.
- Backend на FastAPI: запускает Veo 3.1 через официальный Google GenAI SDK и отдаёт готовый MP4.
- API-ключ задаётся только на сервере через `GEMINI_API_KEY`, не вшивается в APK.

## Важно
Это исходный проект, а не готовый APK. Для сборки APK нужен Android Studio/Android SDK. Для генерации нужен сервер с доступом к Gemini API и включённым биллингом/доступом к Veo. Перед публикацией добавьте аутентификацию, лимиты запросов, хранение заданий в БД и удаление старых видео. Не выставляйте backend открытым в интернет без защиты.

## Запуск backend
В каталоге `backend`:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export GEMINI_API_KEY="ВАШ_НОВЫЙ_КЛЮЧ"  # PowerShell: $env:GEMINI_API_KEY="..."
uvicorn main:app --host 0.0.0.0 --port 8000
```

Для публичного использования настройте HTTPS reverse proxy. В Android-приложении укажите HTTPS URL сервера. Для локальной проверки Android-эмулятора адрес хоста обычно `10.0.2.2`, но manifest приложения требует HTTPS — настройте локальный HTTPS или временно измените проверку/сетевую политику только для отладки.

## Сборка APK
1. Установите Android Studio и Android SDK 35.
2. Откройте папку `VeoStudio` как проект.
3. Дождитесь Gradle Sync.
4. Выберите **Build → Build APK(s)**.
5. APK обычно появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Документация Google
https://ai.google.dev/gemini-api/docs/veo

Модель в этом шаблоне: `veo-3.1-generate-preview`. Google может менять доступность preview-моделей и ограничения параметров.
