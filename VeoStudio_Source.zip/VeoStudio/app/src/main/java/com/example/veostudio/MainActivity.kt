package com.example.veostudio

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException

class MainActivity : Activity() {
    private val http = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var serverUrl: EditText
    private lateinit var prompt: EditText
    private lateinit var aspect: Spinner
    private lateinit var resolution: Spinner
    private lateinit var status: TextView
    private lateinit var generate: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 18, 28)
        window.navigationBarColor = Color.rgb(20, 18, 28)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            setBackgroundColor(Color.rgb(20, 18, 28))
        }
        fun label(text: String) = TextView(this).apply {
            this.text = text; textSize = 15f; setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 6)
        }
        root.addView(TextView(this).apply {
            text = "VEO STUDIO"; textSize = 27f; gravity = Gravity.CENTER_VERTICAL
            setTextColor(Color.WHITE); setPadding(0, 0, 0, 8)
        })
        root.addView(TextView(this).apply {
            text = "Создание видео с Google Veo 3.1"; textSize = 14f
            setTextColor(Color.LTGRAY); setPadding(0, 0, 0, 12)
        })
        root.addView(label("Адрес вашего backend-сервера"))
        serverUrl = EditText(this).apply {
            hint = "https://your-server.example.com"; singleLine = true
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            setBackgroundColor(Color.rgb(43, 40, 52)); setPadding(12, 8, 12, 8)
        }
        root.addView(serverUrl, matchWrap())
        root.addView(label("Опишите видео"))
        prompt = EditText(this).apply {
            hint = "Например: апельсин готовит пиццу на кухне, кинематографичный свет…"
            minLines = 4; gravity = Gravity.TOP; setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY); setBackgroundColor(Color.rgb(43, 40, 52))
            setPadding(12, 12, 12, 12)
        }
        root.addView(prompt, LinearLayout.LayoutParams(-1, 140))
        root.addView(label("Формат"))
        aspect = spinner(listOf("Вертикальный 9:16", "Горизонтальный 16:9"))
        root.addView(aspect, matchWrap())
        root.addView(label("Разрешение"))
        resolution = spinner(listOf("720p", "1080p", "4k"))
        root.addView(resolution, matchWrap())
        generate = Button(this).apply {
            text = "СОЗДАТЬ ВИДЕО"
            setOnClickListener { startGeneration() }
        }
        val btnParams = matchWrap(); btnParams.topMargin = 18
        root.addView(generate, btnParams)
        status = TextView(this).apply {
            text = "Результат появится после завершения генерации."
            textSize = 14f; setTextColor(Color.LTGRAY); setPadding(0, 18, 0, 0)
        }
        root.addView(status, matchWrap())
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
    }

    private fun startGeneration() {
        val base = serverUrl.text.toString().trim().trimEnd('/')
        val text = prompt.text.toString().trim()
        if (!base.startsWith("https://")) { status.text = "Укажите HTTPS-адрес backend-сервера."; return }
        if (text.isBlank()) { status.text = "Введите описание видео."; return }
        generate.isEnabled = false
        status.text = "Отправка задания…"
        scope.launch {
            try {
                val ratio = if (aspect.selectedItemPosition == 0) "9:16" else "16:9"
                val res = resolution.selectedItem.toString()
                val body = JSONObject().put("prompt", text).put("aspect_ratio", ratio).put("resolution", res).toString()
                val created = withContext(Dispatchers.IO) { postJson("$base/generate", body) }
                val jobId = created.getString("job_id")
                status.text = "Задание принято. Генерация может занять несколько минут…"
                var finished = false
                while (!finished) {
                    delay(8000)
                    val state = withContext(Dispatchers.IO) { getJson("$base/jobs/$jobId") }
                    when (state.optString("status")) {
                        "succeeded" -> {
                            val url = state.optString("video_url")
                            status.text = "Видео готово:\n$url\nОткройте ссылку, чтобы просмотреть или сохранить файл."
                            finished = true
                        }
                        "failed" -> { status.text = "Ошибка генерации: ${state.optString("error", "неизвестная ошибка")}"; finished = true }
                        else -> status.text = "Генерация выполняется…"
                    }
                }
            } catch (e: Exception) {
                status.text = "Ошибка подключения: ${e.message ?: "проверьте сервер"}"
            } finally { generate.isEnabled = true }
        }
    }

    private fun postJson(url: String, json: String): JSONObject {
        val request = Request.Builder().url(url).post(json.toRequestBody("application/json; charset=utf-8".toMediaType())).build()
        http.newCall(request).execute().use { response ->
            val content = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}: $content")
            return JSONObject(content)
        }
    }
    private fun getJson(url: String): JSONObject {
        val request = Request.Builder().url(url).get().build()
        http.newCall(request).execute().use { response ->
            val content = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("HTTP ${response.code}: $content")
            return JSONObject(content)
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
