"""Минимальный backend для Veo Studio. Ключ хранится в переменной окружения."""
import os
import uuid
import threading
import time
from typing import Dict, Any
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from google import genai
from google.genai import types

API_KEY = os.environ.get("GEMINI_API_KEY")
if not API_KEY:
    raise RuntimeError("Установите GEMINI_API_KEY в переменных окружения сервера")
client = genai.Client(api_key=API_KEY)
app = FastAPI(title="Veo Studio API")
jobs: Dict[str, Dict[str, Any]] = {}

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=4000)
    aspect_ratio: str = "9:16"
    resolution: str = "720p"

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/generate")
def generate(req: GenerateRequest):
    if req.aspect_ratio not in ("9:16", "16:9"):
        raise HTTPException(400, "Недопустимый формат")
    if req.resolution not in ("720p", "1080p", "4k"):
        raise HTTPException(400, "Недопустимое разрешение")
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "running", "created_at": time.time()}
    threading.Thread(target=run_generation, args=(job_id, req), daemon=True).start()
    return {"job_id": job_id, "status": "running"}

def run_generation(job_id: str, req: GenerateRequest):
    try:
        # В API Veo 3.1 разрешение 1080p/4k поддерживается для 8-секундного видео.
        cfg = types.GenerateVideosConfig(aspect_ratio=req.aspect_ratio, resolution=req.resolution)
        op = client.models.generate_videos(
            model="veo-3.1-generate-preview", prompt=req.prompt, config=cfg
        )
        while not op.done:
            time.sleep(10)
            op = client.operations.get(op)
        if getattr(op, "error", None):
            raise RuntimeError(str(op.error))
        video = op.response.generated_videos[0].video
        os.makedirs("generated", exist_ok=True)
        path = os.path.abspath(os.path.join("generated", f"{job_id}.mp4"))
        client.files.download(file=video, destination=path)
        jobs[job_id] = {"status": "succeeded", "video_url": f"/videos/{job_id}"}
    except Exception as exc:
        jobs[job_id] = {"status": "failed", "error": str(exc)[:500]}

@app.get("/jobs/{job_id}")
def get_job(job_id: str, request: Request):
    job = jobs.get(job_id)
    if not job:
        raise HTTPException(404, "Задание не найдено")
    result = dict(job)
    if result.get("video_url"):
        result["video_url"] = str(request.base_url).rstrip("/") + result["video_url"]
    return result

@app.get("/videos/{job_id}")
def get_video(job_id: str):
    path = os.path.abspath(os.path.join("generated", f"{job_id}.mp4"))
    if not os.path.isfile(path):
        raise HTTPException(404, "Видео не найдено")
    return FileResponse(path, media_type="video/mp4", filename=f"veo-{job_id}.mp4")
